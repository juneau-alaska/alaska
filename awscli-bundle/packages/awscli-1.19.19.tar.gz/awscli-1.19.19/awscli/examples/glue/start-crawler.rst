**To start a crawler**

The following ``start-crawler`` example starts a crawler. ::

    aws glue start-crawler --name my-crawler

Output::

    None

For more information, see `Defining Crawlers <https://docs.aws.amazon.com/glue/latest/dg/add-crawler.html>`__ in the *AWS Glue Developer Guide*.
